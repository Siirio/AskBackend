# Services

Service offerings, branch-level availability, booking lifecycle, and fallback requests. MVP is request-to-book — not automatic calendar slot reservation.

## Key decisions
- Services are NOT products. Scheduled service logic must stay explicit.
- ServiceOffering: business-owned service definition (name, description, category, status).
- ServiceBranchOffer: branch-level visibility, price, duration, schedule text.
- ServiceBranchOffer.active toggles live search appearance.
- ON_DEMAND: works without resources/schedules/windows.
- SCHEDULED: may use resources, schedules, windows, and booking.
- ServiceResource: optional abstract capacity — NOT specialist accounts.
- Three-level time model: requestedStartAt → proposedStartAt → confirmedStartAt/EndAt.
- ActivityDisplayStatus derived at runtime (DISCUSSING/CONFIRMED/CONFIRMATION_DECLINED), never stored.
- Every confirmation/change/cancellation creates system event in conversation.
- Chat-first, button-for-fixation: chat is primary communication; buttons record agreement already reached.
