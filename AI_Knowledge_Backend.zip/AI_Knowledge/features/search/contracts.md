# Search REST API Contract

## Public search

`POST /api/v1/search` is anonymous and does not create requests, chats, recipients, notifications, or supplier outreach.

The JSON contract uses snake_case. `raw_query` is required and is returned unchanged.

### Request

- `raw_query`: complete visible customer query.
- `scope`: `product`, `service`, or `all`.
- `selected_category`, `city`, `sort`, `language`, and `user_location`: optional search inputs.
- `sort`: `intent_match`, `distance`, or `price_asc`.
- `page`: zero-based page, from 0 through 20.
- `page_size`: from 1 through 50.
- `filters`: optional `scope`, `category`, `city`, `min_price`, and `max_price` constraints.
- `overrides`: optional values for the same constraint keys. Explicit overrides take precedence over interpreted values.

### Response

- `raw_query`, `scope`, and `understood_query` preserve the request context.
- `interpreted_constraints` reports each effective constraint with its source.
- `sections` keeps `EXACT` matches separate from `ALTERNATIVE` results.
- Alternative sections include `relaxed_constraints` and a human-readable `reason`.
- `page`, `page_size`, `total`, and `has_next` describe bounded pagination.
- `diagnostics` reports engine, fallback reason, candidate count, and server latency for operations; clients must not render diagnostics.

Cards include brand presentation, price when known, availability state, an honest `availability_warning`, human-readable `match_reasons`, branch/distance context, badges, and opaque contact actions. Availability is never invented.

## Retrieval behavior

Meilisearch is the primary bounded candidate engine. PostgreSQL hydrates canonical data and is the indexed fallback through full-text and trigram candidate SQL. A Meilisearch failure is visible in diagnostics and logs but does not fail search when PostgreSQL is available.

DeepSeek interpretation is optional. Deterministic interpretation always runs, explicit request values win, and a missing key, timeout, malformed response, or provider error falls back to deterministic interpretation.

AI enrichment runs only after `POST /api/v1/platform/ai-enrichment` with `documentType` and `aggregateIds`. It requires `USE_AI_CATALOG_TOOLS`; catalog documents are not enriched automatically.
