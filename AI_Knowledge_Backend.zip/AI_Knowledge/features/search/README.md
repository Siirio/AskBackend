# Unified Search

Product and service search with Meilisearch as retrieval engine + PostgreSQL for hydration. DeepSeek AI structures raw queries into `SearchPlan`. Single endpoint covers both scopes — AI determines intent.

## Architecture
```
raw query → DeepSeek (intent structuring → SearchPlan) → Meilisearch (typo-tolerant retrieval) → PostgreSQL (hydration) → cards
```
Fallback: PostgreSQL in-memory scoring if Meilisearch is unavailable.

## Key decisions
- Meilisearch is retrieval engine (typo tolerance, Russian stemming, synonyms). PostgreSQL is source of truth + hydration.
- Single endpoint POST /api/v1/search — no more scope toggle.
- DeepSeek AI: structures query (searchTerms, categoryHints, brands, priceRange). NEVER selects businesses or invents availability.
- Meilisearch ranking: words > typo > proximity > attribute > exactness. Post-filters for price/city/distance.
- UniqueOffer boosting: DISCOUNT computes effectivePrice. Non-DISCOUNT shows offer name as label.
- Fallback: PostgreSQL in-memory scoring when Meilisearch unavailable or AI API key unset.
- SearchQueryAlias: data-owned expansion table for broad customer wording.
- Search sessions preserve historical snapshots. Customer history reopens fixed saved result state.
